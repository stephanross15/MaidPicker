export default class NotificationAccountDetail {
    public static readonly SECRET_KEY = "AAAAhc_uK0Q:APA91bHDEvIk0mrkYfEhC-5ZwvP9Ioxmsl59BhBr-zYY32h8F3xRw-C3wfgk7wgd4ltGQ60DR1FDt5U4inBS_36YIC8oMO5ieYIlnexJ5tuweu-wLjMqyFpBDNgEKhF2Z3mcSCYtR_Uj3cusP56LggNDItbjsNX6bA";
}
 export const notificationAccountDetail = new NotificationAccountDetail();