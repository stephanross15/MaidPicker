export default class References {
    static readonly USERS_USERID = 'userId';
    static readonly USERS_USERDATA  = 'userData';
    static readonly USERS_OBJECTID = '_id';
    static readonly USERS_AUTHENTICATIONDATA  = 'authenticationData';
    static readonly AUTHENTICATION_USERID = 'userId';
    static readonly AUTHENTICATION_USERDATA  = 'authenticationData';
    

    

    
    
}