/**
 * This will include document names for database
  */
 export default class ModelsDB {
  static readonly USER = 'user';
  static readonly AUTHENTICATION = 'authentication';
  
}
