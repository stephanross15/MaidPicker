/**TwilioAccountDetail
 * This will include Twilio Account detail
 */
export default class  {

    // //  Production
   //  public static readonly ACCOUNT_SID = "ACe314b11f94d9e3fd64391242fef08b29";
    // public static readonly AUTH_TOKEN = "ba054c239c8b49ebac988a3715104a48";
  //   public static readonly FROM = "+19492008469";

    //  Error Testing
    //  public static readonly ACCOUNT_SID = "ACe314b11f94d9e3fd64391242fef029";
    // public static readonly AUTH_TOKEN = "ba054c239c8b49ebac988a3715a48";
    // public static readonly FROM = "+19492069"; 
    
    public static readonly ACCOUNT_SID = "ACe64201ee025babc6655aeb716e3a08ff";
    public static readonly AUTH_TOKEN = "2613cf236f1650528d98a3adae1d9ce7";
    public static readonly FROM = "+18596006913"; 
  
//stephanross15@gmail.com
//SALEKBATI1995@ //SAME AS HEROKO ACCOUNT PASSWORD AND EMAILID stephanross15@gmail.com
//stephanross15@gmail.com SALEKBATI1995@bati github
}